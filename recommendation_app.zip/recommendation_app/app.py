from flask import Flask, request, render_template
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load your data
product = pd.read_csv('product.csv')
user = pd.read_csv('user.csv')
product.dropna(inplace=True)
user.dropna(inplace=True)
product_to_index = {product_name: index for index, product_name in enumerate(product['name'].unique())}

def collaborative_filtering(user_id, user_data, product_data):
    user_data_subset = user_data[user_data['user_id'] == user_id]
    if user_data_subset.empty:
        return []
    user_data_row = user_data_subset.iloc[0]

    interactions = user_data_row[['purchase_history.1', 'purchase_history.2', 'purchase_history.3',
                                  'browsing_behavior.1', 'browsing_behavior.2', 'browsing_behavior.3']].values.flatten()

    interactions_indices = [product_to_index.get(product, -1) for product in interactions if product in product_to_index]

    similar_users = user_data[user_data['user_id'] != user_id]
    similarities = []

    for _, row in similar_users.iterrows():
        other_interactions = row[['purchase_history.1', 'purchase_history.2', 'purchase_history.3',
                                  'browsing_behavior.1', 'browsing_behavior.2', 'browsing_behavior.3']].values.flatten()

        other_interactions_indices = [product_to_index.get(product, -1) for product in other_interactions if product in product_to_index]

        min_length = min(len(interactions_indices), len(other_interactions_indices))
        if min_length > 0:
            similarity = cosine_similarity([interactions_indices[:min_length]], [other_interactions_indices[:min_length]])[0][0]
            similarities.append((row['user_id'], similarity))

    similarities.sort(key=lambda x: x[1], reverse=True)
    top_similar_users = similarities[:5]

    recommended_products = []
    for user_id, _ in top_similar_users:
        user_interactions = user_data[user_data['user_id'] == user_id][['purchase_history.1', 'purchase_history.2', 'purchase_history.3',
                                                                        'browsing_behavior.1', 'browsing_behavior.2', 'browsing_behavior.3']].values.flatten()
        for product in user_interactions:
            if product not in interactions:
                recommended_products.append(product)

    return recommended_products

def content_based_filtering(user_id, product_data):
    user_preferences = user[user['user_id'] == user_id].iloc[0][['preferences.1', 'preferences.2']]

    filtered_products = product_data[(product_data['p_attributes'].str.contains(user_preferences['preferences.1'])) &
                                     (product_data['avg_rating'] >= 4)]

    filtered_products = filtered_products[['p_id', 'img', 'avg_rating', 'ratingCount', 'name']].head(9)
    return filtered_products[['p_id', 'img', 'name']]

def hybrid_recommendation(user_id, user_data, product_data):
    collaborative_recommended = collaborative_filtering(user_id, user_data, product_data)
    content_based_recommended = content_based_filtering(user_id, product_data)['p_id'].tolist()

    hybrid_recommended = list(set(collaborative_recommended + content_based_recommended))

    return hybrid_recommended

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        user_id = int(request.form['user_id'])
        recommendations = content_based_filtering(user_id, product)

        html_output = '<div style="display: flex; flex-wrap: wrap;">'
        for idx, (_, row) in enumerate(recommendations.iterrows()):
            html_output += f'''
            <div style="margin: 10px; text-align: center; margin-bottom: 20px;">
                <img src="{row['img']}" style="width: 300px; height: 400px;">
                <p style="margin-top: 5px;">Recommended p_id: {row['p_id']}</p>
                <p style="margin-top: 5px;">Product Name: {row['name']}</p>
            </div>
            '''
            if idx == 8:
                break
        html_output += '</div>'

        return render_template('index.html', html_output=html_output)
    return render_template('index.html', html_output='')

if __name__ == '__main__':
    app.run(debug=True)
